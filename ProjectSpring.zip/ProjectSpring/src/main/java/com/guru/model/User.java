package com.guru.model;

import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;


import org.apache.tomcat.util.codec.binary.Base64;
import org.hibernate.annotations.BatchSize;
import org.springframework.stereotype.Component;

@Entity
@Table(name = "user")
@Component
public class User {

	@Id   
	@GeneratedValue(strategy = GenerationType.AUTO)   // 
	private Integer id;
	
	private String userName;
	private String userPassword;
	private Integer userAge;
	private String userCity;
	private String gender;
	private String agree;
	
	@Lob
	private byte[] userPic;
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	public User(Integer id, String userName, String userPassword, Integer userAge, 
			String userCity,String gender,String Agree ) {
		super();
		this.id = id;
		this.userName = userName;
		this.userPassword = userPassword;
		this.userAge = userAge;
		this.userCity = userCity;
		this.gender= gender;
		this.agree=Agree;
		
	}
	
	
	public User(Integer id, String userName, String userPassword, Integer userAge, String userCity,String gender,
			String Agree ,byte[] userPic) {
		super();
		this.id = id;
		this.userName = userName;
		this.userPassword = userPassword;
		this.userAge = userAge;
		this.userCity = userCity;
		this.gender=gender;
		this.agree=Agree;
		this.userPic = userPic;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public Integer getUserAge() {
		return userAge;
	}
	public void setUserAge(Integer userAge) {
		this.userAge = userAge;
	}
	
	

	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getUserCity() {
		return userCity;
	}
	public void setUserCity(String userCity) {
		this.userCity = userCity;
		
	}
	
	
	public String getAgree() {
		return agree;
	}
	public void setAgree(String agree) {
		this.agree = agree;
	}
	public byte[] getUserPic() {
		return userPic;
	}
	public void setUserPic(byte[] userPic) {
		this.userPic = userPic;
	}
	public String getUserPicture() {
		return Base64.encodeBase64String(userPic);
	}
	@Override
	public String toString() {
		return "User [id=" + id + ", userName=" + userName + ", userPassword=" + userPassword + ", userAge=" + userAge
				+ ", userCity=" + userCity + ", gender=" + gender + ", agree=" + agree + ", userPic="
				+ Arrays.toString(userPic) + "]";
	}
	
	
	
	
	
	
	
	
}
