
public class AbstractDemo {

	public static void main(String[] args) {
		Shape circle= new Circle();
		Shape square= new Square1();
		circle.setColor();
		circle.calculateArea();
		square.setColor();
		square.calculateArea();

	}

}
