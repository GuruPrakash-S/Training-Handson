
public class Square1 extends Shape {
	public double calculateArea() {
		double b=4*9.5;
		return b;
	}

}
