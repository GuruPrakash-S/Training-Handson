
public class NRIAccount extends BankAccount {
	void applyFixesDeposit() {
		super.interestRate=6.5;
	}
}
